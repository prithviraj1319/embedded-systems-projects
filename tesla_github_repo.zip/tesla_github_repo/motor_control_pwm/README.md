# Motor Control System using PWM

## Overview
This project controls motor speed using PWM. Two buttons are used to increase or decrease the duty cycle, and the current duty cycle is printed to serial output for debugging.

## Features
- PWM-based speed control
- Button input handling
- Serial output for monitoring
- Simple actuator-control style logic

## Hardware
- Arduino Uno or compatible board
- DC motor
- Motor driver module (such as L298N or transistor-based driver)
- 2 push buttons
- External motor power supply

## Pin Mapping
- PWM output: D5
- Increase button: D2
- Decrease button: D3

## How It Works
1. Read button states.
2. Adjust PWM duty cycle in steps.
3. Write updated PWM value to the motor control pin.
4. Print the current duty cycle to serial monitor.
