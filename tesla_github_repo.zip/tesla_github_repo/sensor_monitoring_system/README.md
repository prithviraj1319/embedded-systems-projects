# Real-Time Sensor Monitoring System

## Overview
This project reads a sensor value from an analog input, filters the reading using a moving average, and sends the processed value over serial communication. It also turns on an alert LED when the value crosses a threshold.

## Features
- ADC-based analog input reading
- Moving average filter for noise reduction
- UART/serial output for debugging and monitoring
- LED alert logic based on threshold detection

## Hardware
- Arduino Uno or compatible board
- Analog sensor or potentiometer
- LED
- 220 ohm resistor
- Jumper wires

## Pin Mapping
- Sensor input: A0
- Alert LED: D9

## How It Works
1. Read the analog signal from the sensor.
2. Store recent samples in a small buffer.
3. Compute the average to reduce noise.
4. Print raw and filtered values over serial.
5. Turn the LED on if the filtered value exceeds the threshold.
