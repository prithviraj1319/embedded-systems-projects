# Embedded Systems Projects

This repository contains beginner-to-intermediate embedded systems projects focused on firmware fundamentals relevant to embedded software roles.

## Projects

### 1. Real-Time Sensor Monitoring System
- Reads analog sensor values using ADC
- Applies simple moving-average filtering
- Sends data over serial/UART for monitoring
- Triggers an LED alert when a threshold is crossed

### 2. Motor Control System using PWM
- Controls motor speed using PWM duty cycle
- Increases or decreases speed based on button input
- Demonstrates actuator-style control logic

### 3. SPI and I2C Communication Demo
- Demonstrates basic communication concepts used in embedded systems
- Includes sample Arduino-style master code for SPI and I2C peripherals

## Skills Demonstrated
- C/C++ for embedded development
- ADC, PWM, GPIO
- UART, SPI, I2C
- Basic signal processing
- Debugging and test-oriented development

## Notes
These are compact demonstration projects prepared to showcase embedded systems fundamentals, firmware structure, and hardware-software interaction.
